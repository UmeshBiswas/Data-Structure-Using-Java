#include <stdio.h>
#include <iostream>
#include <queue>
void bfs(int a[100][100], int n);
using namespace std;
int main()
{
    int num_node, node, adjacent_node, i, j;
    int a[100][100];
    int b[100];

    freopen("inputGRAPH.txt", "r", stdin);
    cin>>num_node;
    for(i=0; i<100; i++)
        for(j=0; j<100; j++)
            a[i][j] = 0;
    for(i=1; i<=num_node; i++)
    {
        cin>>node;
        cin>>adjacent_node;
        int temp = adjacent_node;
        while(temp!=-1)
        {
            a[node][adjacent_node] = 1;
            cin>>adjacent_node;
            temp = adjacent_node;
        }

    }


    bfs(a, num_node);
}

void bfs(int a[100][100], int n)
{
    queue <int> q;
    int b[n];
    for(int i=0; i<n; i++)
        b[i] = -1;
    int current = 0;
    b[current] = 1;
    cout<<current<<" ";



    for(int i=0; i<n; i++)
    {
        if(a[current][i]==1 && b[i]==-1)
        {
            q.push(i);
            b[i] = 1;

        }
    }



    while(!q.empty())
    {
        current = q.front();
        q.pop();
        b[current] = 1;
        cout<<current<<" ";
        for(int i=0; i<n; i++)
        {
            if(a[current][i]==1 && b[i]==-1)
            {
                q.push(i);
                b[i] = 1;

            }


        }
    }



}




