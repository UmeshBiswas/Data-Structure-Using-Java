#include <stdio.h>
#include <iostream>
#include <queue>
using namespace std;
int main()
{
    int num_node, i, j;
    char adjacent_node;
    char a[100][100];

    freopen("inputCharGRAPH.txt", "r", stdin);
    cin>>num_node;
    for(i=0; i<100; i++)
        for(j=0; j<100; j++)
            a[i][j] = '#';
    for(i=0; i<num_node; i++)
    {
        cin>>a[i][0];
        cin>>adjacent_node;
        int k = 1;
        char temp = adjacent_node;
        while(temp!='*')
        {
            a[i][k++] = adjacent_node;
            cin>>adjacent_node;
            temp = adjacent_node;
        }

    }

    for(i=0; i<num_node; i++)
    {

        for(j=0; j<num_node; j++)
        {

            if(a[i][j]!='#')
                cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }
}

