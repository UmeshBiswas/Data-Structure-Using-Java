#include <stdio.h>
#include <iostream>
#include <queue>
using namespace std;
int main()
{
    int num_node, node, adjacent_node, i, j;
    int indegree=-1;
    int a[100][100];

    freopen("inputGRAPH.txt", "r", stdin);
    cin>>num_node;
    for(i=0; i<100; i++)
        for(j=0; j<100; j++)
            a[i][j] = 0;
    for(i=1; i<=num_node; i++)
    {
        cin>>node;
        cin>>adjacent_node;
        int temp = adjacent_node;
        while(temp!=-1)
        {
            a[node][adjacent_node] = 1;
            cin>>adjacent_node;
            temp = adjacent_node;
        }

    }

  /*  for(i=0; i<num_node; i++)
    {
        cout<<i<<"    ";
        for(j=0; j<num_node; j++)
        {

            if(a[i][j]==1)
                cout<<j<<" ";
        }
        cout<<endl;
    }*/
    int sum=0;


for(int j=0;j<num_node;j++){
    sum=sum+j;

}
printf("%d",indegree);

}
