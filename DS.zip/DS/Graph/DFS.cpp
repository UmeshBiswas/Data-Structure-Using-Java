#include <stdio.h>
#include <iostream>
#include <stack>
void bfs(int a[100][100], int n);
using namespace std;
int main()
{
    int num_Node, Node, adjacent_Node, i, j;
    int a[100][100];
    int b[100];

    freopen("inputGRAPH.txt", "r", stdin);
    cin>>num_Node;
    for(i=0; i<100; i++)
        for(j=0; j<100; j++)
            a[i][j] = 0;
    for(i=1; i<=num_Node; i++)
    {
        cin>>Node;
        cin>>adjacent_Node;
        int temp = adjacent_Node;
        while(temp!=-1)
        {
            a[Node][adjacent_Node] = 1;
            cin>>adjacent_Node;
            temp = adjacent_Node;
        }
    }


    bfs(a, num_Node);
}

void bfs(int a[100][100], int n)
{
    stack <int> s;
    int b[n];
    for(int i=0; i<n; i++)
        b[i] = -1;
    int current = 0;
    b[current] = 1;
    cout<<current<<" ";

    for(int i=0; i<n; i++)
    {
        if(a[current][i]==1 && b[i]==-1)
        {
            s.push(i);
            b[i] = 1;

        }
    }

    while(!s.empty())
    {
        current = s.top();
        s.pop();
        b[current] = 1;
        cout<<current<<" ";
        for(int i=0; i<n; i++)
        {
            if(a[current][i]==1 && b[i]==-1)
            {
                s.push(i);
                b[i] = 1;

            }

        }
    }

}




