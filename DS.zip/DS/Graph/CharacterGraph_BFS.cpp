#include <stdio.h>
#include <iostream>
#include <queue>
int ifIS(char a[], int n, char c);
int getindex(char c, char a[100][100], int n);
void bfs(char a[100][100], int n);
using namespace std;
int main()
{
    int num_node, i, j;
    char adjacent_node;
    char a[100][100];

    freopen("inputCharGRAPH.txt", "r", stdin);
    cin>>num_node;
    for(i=0; i<100; i++)
        for(j=0; j<100; j++)
            a[i][j] = '#';
    for(i=0; i<num_node; i++)
    {
        cin>>a[i][0];
        cin>>adjacent_node;
        int k = 1;
        char temp = adjacent_node;
        while(temp!='*')
        {
            a[i][k++] = adjacent_node;
            cin>>adjacent_node;
            temp = adjacent_node;
        }

    }


    bfs(a, num_node);




}






int ifIS(char a[], int n, char c)
{
    int f = 0;
    for(int i=0; i<n; i++)
    {
        if(c==a[i])
        {
            f=1;
            break;
        }

    }
    return f;

}




int getindex(char c, char a[100][100], int n)
{

    for(int i=0; i<n; i++)
    {
        if(a[i][0]==c)
            return i;
    }
}















void bfs(char a[100][100], int n)
{
    queue <char> q;
    char b[n];
    for(int i=0; i<n; i++)
        b[i] = '$';
    int current = 0;
    b[current++] = a[0][0];

    cout<<a[0][0]<<" ";

    for(int i=1; i<n; i++)
    {
        if(a[0][i]!='#' && ifIS(b,n,a[0][i])==0)
        {
            q.push(a[0][i]);
            b[current++] = a[0][i];

        }


    }

    while(!q.empty())
    {
        char c = q.front();
        q.pop();
        cout<<c<<" ";
        for(int i=1; i<n; i++)
        {
            if(a[getindex(c,a,n)][i]!='#' && ifIS(b,n,a[getindex(c,a,n)][i])==0)
            {
                q.push(a[getindex(c,a,n)][i]);
                b[current++] = a[getindex(c,a,n)][i];

            }


        }


    }





}
