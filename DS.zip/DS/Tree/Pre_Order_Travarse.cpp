#include <iostream>
using namespace std;
void preorder (int i, int n, int tree[]);
int main()
{
    int tree[] = {43, 31, 64, 20, 40 ,56 , 89, -1, 28, 33, -1, 47, 59, -1, -1};
    preorder(0, 15, tree);
}

void preorder (int i, int n, int tree[])
{
if (i<n && tree[i]!=-1)
{
    cout<< tree[i]<<" ";
    preorder (2*i+1, n, tree);
    preorder(2*i+2, n, tree);
}
}
