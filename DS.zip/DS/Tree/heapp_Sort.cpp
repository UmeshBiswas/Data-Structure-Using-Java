#include <iostream>
using namespace std;
void create_Heap(int A[], int n);
int main()
{
    int a[] = {12, 10, 5, 6, 3, 45};


    for(int k = 6; k>1; k-- )
    {
        create_Heap(a, k);
        int temp = a[k-1];
        a[k-1] = a[0];
        a[0] = temp;
    }

     for(int i=0; i<6; i++)
        cout<<a[i]<<" ";


}
void create_Heap(int A[], int n)
{
    int i,k,temp;
    for (i = 1; i<n; ++i)
    {
        temp=A[i];
        k = i;
        while (k > 0 and A[(k-1)/2] < temp)
        {
            A[k] = A[(k-1)/2];
            k = (k-1)/2;
        }
        A[k] = temp;
    }

}
