#include <iostream>
using namespace std;
void search_Node(int a[], int n, int root, int value);
int main()
{
    int a[] = {43, 31, 64, 20, 40, 56, 89};
    search_Node(a,7,0,64);
}

void search_Node(int a[], int n, int root, int value)
{
    int f = 0;
    while(root<n)
    {
        if(a[root]==value)
        {
            cout<<"Found at "<<root<<endl;
            f = 1;
            break;
        }
        else if(value>a[root])
        {
            root = 2*root + 2;
            search_Node(a,n,root,value);
        }
        else
        {
            root = 2*root + 1;
            search_Node(a,n,root,value);
        }
    }
    if(f==0)
        cout<<"Not Found!"<<endl;
}
