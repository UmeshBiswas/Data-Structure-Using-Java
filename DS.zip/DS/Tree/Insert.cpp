#include <iostream>
using namespace std;
int main()
{
    int a[] = {43, 31, 64, 20, 40, -1, 89};
    int t[100];
    int n = 7;
    int item = 100;
    int i = 0;
    while(i<n)
    {
        if(a[i]==item)
            break;
        else if(item<a[i])
            i=2*i+1;
        else
            i=2*i+2;
    }
    int k = i+1;
    if(i>n)
    {
        int j;
        for( j=0; j<i; j++)
        {
            if(j>=n)
                t[j]=-1;
            else
                t[j]=a[j];
        }
        t[j]=item;
    }
    int m=i;
    else
    {
        while(i<n)
        {
            t[]
        }
    }
    for(int i=0; i<k; i++)
        cout<<t[i]<<" ";

}
