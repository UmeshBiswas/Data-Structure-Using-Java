#include <iostream>
using namespace std;
void inorder (int tree[], int root);
int main()
{
    int tree[] = {43, 31, 64, 20, 40 ,56 , 89, -1, 28, 33, -1, 47, 59, -1, -1};
    inorder(tree, 0);
}

void inorder (int tree[], int root)
{
    if(tree[2*root+1]!=-1)
    {
        root = 2*root +1;
        inorder(tree, 2*root+1);
        inorder(tree, 2*root+2);
    }
    else
        cout<<tree[root]<<" ";

    cout<<tree[0]<<" ";

   /* if(tree[2*root+2]!=-1)
    {
        root = 2*root +2;
        inorder(tree, 2*root+2);
    }
    else
        cout<<tree[root]<<" ";*/
}

