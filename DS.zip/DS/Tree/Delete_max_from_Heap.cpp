#include <iostream>
using namespace std;
void deletee(int a[], int n);
int main()
{
    int a[] = {90, 80, 65, 50, 45, 55, 40, 30, 25};
    deletee(a, 9);
    for(int i=0; i<8; i++)
        cout<<a[i]<<" ";
}

void deletee(int a[], int n)
{
    int i,temp;
    temp= a[n-1];
    i = 1;
    while (i<n)
    {
        if ((i<n-1) and (a[i]<a[i+1]))
        i= i+1;
        if (temp>=a[i])
            break;
        a[(i-1)/2]=a[i];
        i=2*i+1;
    }
    a[(i-1)/2]=temp;

}
