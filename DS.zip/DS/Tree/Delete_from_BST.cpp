#include <iostream>
using namespace std;
void deletee(int a[], int n, int item);
int main()
{
    int a[] = {43, 32, 64, 20, 40, 56, 89, -1, 28, 33, -1, 47, 59, -1, -1};
    deletee(a,15, 64);
    for(int i=0; i<15; i++)
        cout<<a[i]<<" ";
}

void deletee(int a[], int n, int item)

{
    int i=0;
    while(i<n)
    {
        if(a[i]==item)
        {
            int k=2*i+1;
            int temp;
            while(k<n)
            {

                if(a[k]!=-1)
                    temp = k;
                k=2*k+2;
            }
            a[i]=a[temp];
            a[temp]=-1;
            break;
        }
        else if(item<a[i])
            i=2*i+1;
        else
            i=2*i+2;
    }
}
