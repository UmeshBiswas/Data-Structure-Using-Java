#include <iostream>
using namespace std;
void create_Heap(int a[], int n);
int main()
{
    int a[] = {45, 28, 52, 25, 60, 70};
    create_Heap(a, 6);
    for(int i=0; i<6; i++)
        cout<<a[i]<<" ";
}

void create_Heap(int A[], int n)
{
    int i,k,temp;
    for (i = 1; i<n; ++i)
    {
        temp=A[i];
        k = i;
        while (k > 0 and A[(k-1)/2] < temp)
        {
            A[k] = A[(k-1)/2];
            k = (k-1)/2;
        }
        A[k] = temp;
    }

}

